from django.apps import AppConfig


class DrfQuickstartConfig(AppConfig):
    name = 'DRF_quickstart'
